// import React,{Component}from "react";

// class Table extends Component {
//     state={
//         orderData: []
//     }
//     componentDidMount(){
//         axios.get('http://127.0.0.1:8080/get')
//     .then(response =>{
//         this.setState({orderData: response.orderData});
//     })   

//  });
// }